<?php

if (defined('PLUGIN_FACTORY')) return;
define('PLUGIN_FACTORY', true);

define('PFACTORY_DIR', dirname(__FILE__));
define('PFACTORY_URL', plugins_url(null,  __FILE__ ));

include_once('factory-loader.class.php');
include_once('factory.class.php');
include_once('entities/_loader.php');