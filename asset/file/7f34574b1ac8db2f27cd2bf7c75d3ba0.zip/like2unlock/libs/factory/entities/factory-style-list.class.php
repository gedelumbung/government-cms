<?php

class PFactoryStyleList extends PFactoryAssetsList 
{
    public function connect() {
        
        $aseetUrl = $this->factory->pluginUrl . '/assets/';
        
        foreach ($this->getAllRequired() as $style) {
            wp_enqueue_style( $style );
        }       
        
        foreach ($this->getAll() as $style) {
            wp_enqueue_style( $style, str_replace('~/', $aseetUrl, $style));
        }  
    }
}
