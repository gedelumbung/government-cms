<?php

class PFactoryAssetsList extends PFactoryList 
{
    private $required = array();
    public $factory;
    
    public function __construct( $factory ) {
        $this->factory = $factory;
    }
    
    /**
     * Checks whether the collection is empty.
     * @return boolean
     */
    public function isEmpty() {
        return empty($this->items) && empty($this->required);
    }
    
    /**
     * Adds new items to the requried collection.
     * @param mixed
     */
    public function requireItem() {
        foreach(func_get_args() as $item) {
            $this->required[] = $item;
        }        
    }
    
    /**
     * Returns all metaboxes as an array.
     * @return array
     */
    public function getAllRequired() {
        return $this->required;
    }
}
