<?php

class PFactoryScriptList extends PFactoryAssetsList 
{
    public $localizeData = array();
    
    public function connect() {
        
        $aseetUrl = $this->factory->pluginUrl . '/assets/';
        
        foreach ($this->getAllRequired() as $script) {
            wp_enqueue_script( $script );
        }        
        
        foreach ($this->getAll() as $script) {
            wp_register_script( $script, str_replace('~/', $aseetUrl, $script), array('jquery'), false, true);
            
            if ( !empty( $this->localizeData[$script] ) ) {
                wp_localize_script( $script, $this->localizeData[$script][0], $this->localizeData[$script][1] );   
            }
            
            wp_enqueue_script( $script );
        } 
    }
    
    public function localize($script, $varname, $data) {
        $this->localizeData[$script] = array($varname, $data);
    }
}
