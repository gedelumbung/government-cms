<?php

class PFactoryForm {
    
    /**
     * Value provider of the current form.
     * @var IPFactoryValueProvider 
     */
    private $valueProvider;
    
    private $tabs = array();
    private $currentTab;
    private $currentGroup;
    
    public $scope;
    
    public $controls = array();
    
    private $defaultControls = array(
        'textbox', 'textarea', 'checkbox', 'list', 'editor', 'url', 'integer');
    
    public function __construct( $valueProvider = null ) {
        $this->valueProvider = $valueProvider ? $valueProvider : new PFactoryFakeValueProvider();
        
        $this->tabs = array(
            array(
                'title' => 'Default Tab',
                'name' => 'default-tab',
                'groups' => array(
                    array(
                        'title' => 'Default Settings',
                        'name' => 'default-settings',
                        'controls' => array()
                    )
                )
            )
        );
        $this->currentTab = &$this->tabs[0];
        $this->currentGroup = &$this->currentTab['groups'][0];      
    }
    
    public function add( $array ) {
        
        foreach($array as &$item) {
            
            if ( isset( $item['type'] ) ) {

                switch( $item['type'] ) {
                    case 'tab':
                        $this->addTabItem($item);
                        break;
                    case 'group':
                        $this->addGroupItem($item);
                        break;
                    default:
                        $this->addControlItem($item);
                }
            }
        }
    }
    
    /**
     * Creates control using given data.
     */
    public function build() {
        
        $workTabs = array();
        foreach ($this->tabs as &$tab) {
            if ( 
                count( $tab['groups'] ) > 1 || 
                count( $tab['groups'][0]['controls'] ) > 0 ) {
                
                $workTabs[] = $tab;
            }
        } 
        
        // display tabs' contents
        if ( count($workTabs) > 0 ) {
            
            foreach( $workTabs as &$workTab ) {

                foreach( $workTab['groups'] as &$group ) { 
                        
                    if ( $group['name'] !== 'default-settings' || count($group['controls']) > 0 ) {
                    
                        foreach( $group['controls'] as &$control ) {

                            $objectToRender = null;

                            if ( gettype($control['type']) == 'string' ) {
                                if ( in_array( $control['type'], $this->defaultControls ) ) {

                                    switch ($control['type'] ) {
                                        case 'textbox':
                                            $objectToRender = new PFactoryTextboxFormControl();
                                            break;
                                        case 'textarea':
                                            $objectToRender = new PFactoryTextareaFormControl();
                                            break;
                                        case 'checkbox':
                                            $objectToRender = new PFactoryCheckboxFormControl();
                                            break;
                                        case 'list':
                                            $objectToRender = new PFactoryListFormControl();
                                            break;
                                        case 'editor':
                                            $objectToRender = new PFactoryEditorFormControl();
                                            break;     
                                        case 'integer':
                                            $objectToRender = new PFactoryIntegerFormControl();
                                            break; 
                                        case 'url':
                                            $objectToRender = new PFactoryUrlFormControl();
                                            break;                                     
                                    }
                                }
                                
                            } elseif ( gettype($control['type']) == 'object' ) {
                                $objectToRender = $control['type'];
                            }
                            
                            if (  !$objectToRender ) {
                                print_r($control);
                                die( sprintf('[ERROR] Invalid control type for the field "%s".', $control['name']));
                            }
                            
                            $control['default'] = isset($control['default']) ? $control['default'] : null;
                            $control['scope'] = $this->scope;
                            $control['fullname'] = ( !empty($this->scope) ) 
                                ? $this->scope . '_' . $control['name']
                                : $control['name'];
                            
                            $objectToRender->setup($control, $this->valueProvider);
                            $control['control'] = $objectToRender;

                            $this->controls[] = $control['control'];
                        }
                    } 
                }
            }  
        } 
        
        $this->tabs = $workTabs;
    }
    
    public function render() {
    
        $this->build();
        $hasTabs = count($this->tabs) > 1;
        
        // display tabs' headers
        if ( $hasTabs ) {
            $firstTab = "active";
            ?>
                <div class='pi-tab-headers-wrap'>
                    <ul class="nav nav-tabs">
                    <?php foreach( $this->tabs as &$workTab ) { ?>
                        <li class='pi-tab-title <?php echo $firstTab ?>'>
                            <a href="#tab-<?php echo $workTab['name'] ?>" data-toggle="tab">
                                <?php echo $workTab['title'] ?>
                            </a>
                        </li>
                    <?php $firstTab = ''; } ?>
                    </ul>
                </div>
            <?php       
            unset( $workTab );
        }
        
        echo '<div class="wpbootstrap ' . ($hasTabs ? 'has-tabs' : '') . '">';
        
        // display tabs' contents
        if ( count($this->tabs) > 0 ) {
            ?>
                <div class='tab-content pi-tab-contens-wrap'>
                    <?php 
                    $firstTab = "active";
                    foreach( $this->tabs as &$workTab ) { ?>
                    <div id="tab-<?php echo $workTab['name'] ?>" class="tab-pane <?php echo $firstTab ?> pi-tab-content-wrap">
                        <div class="form-horizontal">
                        <?php 
                            $noLegend = count( $workTab['groups'] ) <= 1;
                            foreach( $workTab['groups'] as &$group ) { 
                            if ( 
                               ( $group['name'] == 'default-settings' && count($group['controls']) > 0 ) ||
                                 $group['name'] != 'default-settings'    
                               ) {
                        ?>
                        <fieldset class='pi-content-group' id='group-<?php echo $group['name'] ?>'>
                            <?php if ( !$noLegend ) { ?>
                            <legend><?php echo $group['title'] ?></legend>
                            <?php } ?>
                            <?php foreach( $group['controls'] as &$control ) {
                                $control['control']->render();
                            } ?>
                        </fieldset>
                        <?php } 
                        $firstTab = '';
                        } ?>
                        </div>
                    </div>
                    <?php } ?>
                </div>
            <?php       
        } 
        
        echo '</div>';
    }
    
    public function addTabItem($item) {
        
        $this->tabs[] = $item;
        $this->currentTab = &$this->tabs[count($this->tabs) - 1];
        
        $this->currentTab['groups'] = array(
            array(
                'title' => 'Default Settings',
                'name' => 'default-settings',
                'controls' => array()
            )
        );
        $this->currentGroup = &$this->currentTab['groups'][0];
    }
    
    public function addGroupItem($item) {
        
        $this->currentTab['groups'][] = $item;
        $this->currentGroup = &$this->currentTab['groups'][count($this->currentTab['groups']) - 1];  
    }
    
    public function addControlItem($item) {
        
        $this->currentGroup['controls'][] = $item;
    }    
    
    public function addTab($title, $name = null) {
        
        $name = $name ? $name : $this->generateRandomName();
        
        $this->addTabItem(array(
            'type' => 'tab',
            'name' => $name,
            'title' => $title
        ));
    }
    
    public function addGroup($title, $name = null) {
        
        $name = $name ? $name : $this->generateRandomName();
        
        $this->addGroupItem(array(
            'type' => 'group',
            'name' => $name,
            'title' => $title
        ));     
    }
    
    private function generateRandomName($length = 10) {
        
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }
   
}