<?php

abstract class PFactoryShortcode {
    
    /**
     * Shortcode name.
     * @var string
     */
    public $shortcode = null;
    
    /**
     * Current factory
     * @var PFactory
     */
    public $factory;
    
    /**
     * Scripts to include on the same page.
     * @var PFactoryScriptList 
     */
    public $scripts;
    
    /**
     * Styles to include on the same page.
     * @var PFactoryStyleList 
     */
    public $styles;
    
    public function __construct( PFactory $factory ) {
        $this->factory = $factory;
        $this->scripts = new PFactoryScriptList( $factory );
        $this->styles = new PFactoryStyleList( $factory );
    }

    /**
     * Shortcode configuration.
     */
    public abstract function configure(PFactoryScriptList $scripts, PFactoryStyleList $styles);
    
    /**
     * Renders shortcode.
     */
    public abstract function render($attr, $content);
                    
    /**
     * Registers the shortcode.
     */
    public function register() {
        
        $this->configure($this->scripts, $this->styles);
        
        $this->styles->connect();
        add_shortcode( $this->shortcode, array( &$this, 'execute' ));
    }
    
    public function execute($attr, $content) {
        
        $this->scripts->connect();
        
        ob_start();
        $this->render($attr, $content);
        $html = ob_get_clean();
        
        return $html;
    }
}