<?php

abstract class PFactoryStandartFormControl extends PFactoryFormControl {
    
    public function render()
    {
        $value = $this->provider->getValue( $this->info['name'], $this->info['default'] );

        ?>
            <div class='control-group'>
                <label class='control-label' for='<?php echo $this->info['fullname'] ?>'>
                    <?php echo $this->info['title'] ?>
                </label>
                <div class='controls'>
                    <?php $this->renderInput( $this->info, $value, $this->info['fullname'] ) ?>
                </div>
            </div>
        <?php
    }
    
    protected abstract function renderInput( $control, $value, $name );
}