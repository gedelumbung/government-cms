<?php

class PFactoryIntegerFormControl extends PFactoryTextboxFormControl 
{
    public function getValue($name) {
        $value = intval( parent::getValue($name) );
        return $value != 0 ? $value : null;
    }
}