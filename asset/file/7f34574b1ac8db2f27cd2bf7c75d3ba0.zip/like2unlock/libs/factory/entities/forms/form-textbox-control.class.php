<?php

class PFactoryTextboxFormControl extends PFactoryStandartFormControl 
{
    protected function renderInput( $c, $value, $fullname ) {
        $sizeAtrr = (!empty( $c['size'] )) ? 'maxlength="' . $c['size'] . '"' : '';
        $this->addClass( ( !empty( $c['size'] ) ) ? ('size-' . $c['size']) : '' );
        
        $isAppend = (!empty( $c['append'] ));  
        ?>

            <input 
                type="text" <? echo $sizeAtrr ?> 
                value="<?php echo $value ?>" 
                class="<?php echo $this->getClasses() ?>"
                id="<?php echo $fullname ?>" name="<?php echo $fullname ?>" />
            
            <span><?php if ($isAppend) { echo $c['append']; } ?></span>
        
        
        <?php if ( !empty( $c['hint'] ) ) { ?>
            <span class='help-block'><?php echo $c['hint'] ?></span>    
        <?php } 
    }   
}