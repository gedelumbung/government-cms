<?php

class PFactoryEditorFormControl extends PFactoryFormControl 
{

    public function render()
    {
    $value = $this->provider->getValue( $this->info['name'], $this->info['default'] );
    
    $tinymceInit = array();
    if ( !empty( $this->info['eventCallback'] ) )
        $tinymceInit['handle_event_callback'] = $this->info['eventCallback'];
    
    $tinymceInit['content_css'] = PFACTORY_URL . '/assets/css/editor.css';  

    ?>
        <div class='control-group pi-editor-wrap pi-editor-<?php echo $this->info['fullname'] ?>'>
            <label class='control-label' for='<?php echo $this->info['fullname'] ?>'>
                <?php echo $this->info['title'] ?>
                <?php if ( !empty( $this->info['hint'] ) ) { ?>
                    <span class='help-block'><?php echo $this->info['hint'] ?></span>    
                <?php } ?>
            </label>
            <div class='controls'>
                
                <div class='pi-editor'>
                <?php wp_editor( $value, $this->info['fullname'], array(
                    'textarea_name' => $this->info['fullname'],
                    'wpautop' => false,
                    'teeny' => true,
                    'tinymce' => $tinymceInit
                )); ?> 
                </div>
            
            </div>
        </div>
    <?php
    }
}