<?php

class PFactoryCheckboxFormControl extends PFactoryStandartFormControl 
{
    protected function renderInput( $c, $value, $fullname ) {
        $checked = $value ? 'checked="checked"' : '';
        $enableClass = $value ? 'selected' : '';
        $disableClass = $value ? '' : 'selected';
        
        ?>
            <div class="pi-switch">
                <label class="pi-switch-enable <?php echo $enableClass ?>"><span>On</span></label>
                <label class="pi-switch-disable <?php echo $disableClass ?>"><span>Off</span></label>
                <input type='checkbox' value='1' <?php echo $checked ?> name='<?php echo $fullname ?>' id='<?php echo $fullname ?>' />
            </div>
            <?php if ( !empty( $c['hint'] ) ) { ?>
                <span class="help-block"><?php echo $c['hint'] ?></span>    
            <?php } ?>
        <?php
    }
    
    public function getValue( $name ) {
        $fullname = ( !empty( $this->info['scope'] )) ? $this->info['scope'] . '_' . $name : $name;
        return isset($_POST[$fullname]) ? 'true' : 'false';
    }
}