<?php

abstract class PFactoryFormControl {
    
    public $factory;
    public $info;
    public $provider;
    public $classes = array();
    
    public function setup( &$controlInfo, IPFactoryValueProvider $provider ) {
        
        $this->info = $controlInfo;
        $this->provider = $provider; 
        
        if ( !empty( $controlInfo['class'] )) {
            foreach( explode($controlInfo['class'], ' ') as $class ) {
                $this->classes[] = $class;
            }
        }
    }
    
    /**
     * Returns control name used to save data by provider.
     */
    public function getName() 
    {
        return $this->info['name'];
    }
    
    /**
     * Returns set of classses that must be applied to the control.
     * @return string 'class1 class2 class3' or empty string ''
     */
    protected function getClasses() {
        return implode(' ', $this->classes);
    }
    
    /**
     * Adds class to the classes' set.
     * @param type $className
     */
    protected function addClass( $className ) {
        if ( empty($className) ) return;
        if ( !in_array($className, $this->classes )) $this->classes[] = $className;
    }
    
    /**
     * Renders the control using control's info and value got from a value provider.
     */
    public abstract function render();
    
    /**
     * Returns result's value.
     */
    public function getValue( $name ) {   
        $fullname = ( !empty( $this->info['scope'] )) ? $this->info['scope'] . '_' . $name : $name;
        return isset( $_POST[$fullname] ) ? $_POST[$fullname] : null;
    }
    
  
}