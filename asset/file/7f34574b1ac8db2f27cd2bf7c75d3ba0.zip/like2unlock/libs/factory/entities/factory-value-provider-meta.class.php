<?php

class PFactoryMetaValueProvider implements IPFactoryValueProvider 
{
    private $values = array();
    private $meta = array();
    public $scope;
    
    public function init( $scope, $postId = false ) {
        global $post;
            
        $this->scope = preg_replace('/_meta_box$/', '', $this->formatCamelCase( $scope ) );
        $this->postId = $postId ? $postId : $post->ID;
        $temp = get_post_meta( $this->postId );
        
        foreach($temp as $key => &$content) {
            if ( strpos( $key, $this->scope ) === 0 ) {
                $this->meta[$key] = $content;
            }
        }
    }

    public function saveChanges() {
        
        $postId = $this->postId;
        $deleted = $this->meta;

        foreach ($this->values as $key => $value) {
            
            update_post_meta($postId, $key, $value);
        }
    }

    public function getValue($name, $default = null) {
        
        $value = isset( $this->meta[$this->scope . '_' . $name] ) 
                ? $this->meta[$this->scope . '_' . $name][0] 
                : $default;
        
        if ($value === 'true') $value = true;
        if ($value === 'false') $value = false;
        
        return $value;
        // return (!$value) ? $default : $value;
    }

    public function setValue($name, $value) {
        
        $this->values[$this->scope . '_' . $name] = $value;
        return;
    }
    
    private function formatCamelCase( $string ) {
        $output = "";
        foreach( str_split( $string ) as $char ) {
                strtoupper( $char ) == $char and $output and $output .= "_";
                $output .= $char;
        }
        $output = strtolower($output);
        return $output;
    }
}