<?php

/**
 * @link http://codex.wordpress.org/Function_Reference/add_meta_box
 */
abstract class PFactoryMetabox {
    
    /**
     * Id of the metabox. 
     * Be default, the current class name is used.
     * @var string 
     */
    public $id = null;
    
    /**
     * Visible title of the metabox.
     * @var string
     */
    public $title = '[Metabox]';
    
    /**
     * Placeholder of the metabox ('normal', 'side', 'advanced')
     * @var string 
     */
    public $context = 'normal';
    
    /**
     * Priority of the metabox.
     * @var string
     */
    public $priority = 'default';
    
    /**
     * Post types to display the metabox.
     * @var array
     */
    public $types = array();
    
    /**
     * Current factory.
     * @var PFactory
     */
    public $factory;
    
    /**
     * Scripts that required to include.
     * @var PFactoryScriptList
     */
    public $scripts;
    
    /**
     * Styles that required to include.
     * @var PFactoryStyleList
     */  
    public $styles;
    
    public function __construct( PFactory $factory = null ) {
        $this->factory = $factory;
    }
    
    /**
     * Adds a new post type where the metabox appear.
     * @param string $typeName
     */
    public function addType( $typeName ) {
        
       if ( !in_array($typeName, $this->types) ) {
           $this->types[] = $typeName;
       }
    }
    
    public function configure(PFactoryScriptList $scripts, PFactoryStyleList $styles) {
        // method must be overriden in the derived classed.
    }

    public function register() {
        
        $this->scripts = new PFactoryScriptList( $this->factory );
        $this->styles = new PFactoryStyleList( $this->factory );
        
        $this->configure( $this->scripts, $this->styles );
        
        if ( !empty( $this->types ) ) {
            add_action('add_meta_boxes', array($this, 'actionAddMetabox'));
            add_action('save_post', array($this, 'saveMetaData'));

            if ( !$this->scripts->isEmpty() || !$this->styles->isEmpty() ) {
                add_action('admin_enqueue_scripts', array($this, 'actionAdminScripts'));
            }
        }
    }
    
    /**
     * Registers metaboxes added during type's configuration.
     */
    public function actionAddMetabox() {
        
        foreach($this->types as $type) {
        
            add_meta_box( 
                ($this->id) ? $this->id : get_class($this), 
                $this->title,
                array($this, 'show'), 
                $type, 
                $this->context, 
                $this->priority 
            );
        }
    }
    
    /**
     * Adds scripts and styles for the metabox.
     * @param type $hook
     */
    public function actionAdminScripts( $hook ) {
        global $post;
            
        if ( !in_array( $hook, array('post.php', 'post-new.php'))) return;
        if ( $this->scripts->isEmpty() && $this->styles->isEmpty() ) return;
        if ( !in_array( $post->post_type, $this->types)) return;

        $aseetUrl = $this->factory->pluginUrl . '/assets/';
        
        foreach ($this->scripts->getAllRequired() as $script) {
            wp_enqueue_script( $script );
        }        
        
        foreach ($this->scripts->getAll() as $script) {
            wp_enqueue_script( $script, str_replace('~/', $aseetUrl, $script), array('jquery'), false, true);
        }

        foreach ($this->styles->getAllRequired() as $style) {
            wp_enqueue_style( $style );
        }       
        
        foreach ($this->styles->getAll() as $style) {
            wp_enqueue_style( $style, str_replace('~/', $aseetUrl, $style));
        }          
    }
    
    /**
     * Saves metabox data.
     * @param int $post_id
     * @param object $post
     * 
     * @todo remove multiple permossion for post edition.
     */
    public function saveMetaData( $post_id ) {
        
        // Verify the post type
        if ( !isset( $_POST['post_type'] ) ) return $post_id;
        
        $post_type = $_POST['post_type'];
        if ( !in_array( $post_type, $this->types ) ) return $post_id;
        
        // Verify the nonce before proceeding
        $className = strtolower( get_class($this) );  
        $nonceName = $className . '_factory_nonce';
        $nonceValue = $className  . '_pfactory';
        
        if ( !isset( $_POST[$nonceName] ) || !wp_verify_nonce( $_POST[$nonceName], $nonceValue ) )
            return $post_id;
        
        if ( wp_is_post_revision( $post_id ) ) return $post_id;
        
        // Get the post type object.
	$post_type = get_post_type_object( $post_type );

	// Check if the current user has permission to edit the post.
	if ( !current_user_can( $post_type->cap->edit_post, $post_id ) ) return $post_id;
        
        // All right, save data.
        $this->save( $post_id );
    }
    
    /**
     * Renders content of the current metabox.
     */
    public function show() {
        
        // security nonce
        $className = strtolower( get_class($this) );
        wp_nonce_field( $className  . '_pfactory', $className . '_factory_nonce' );
        
        ob_start();
        $this->render();
        $content = ob_get_clean();
        
        echo $content;
    }
    
    public function render() {             
        echo 'Define the method "html" in your metabox class.';
    }
    
    public function save( $postId ) {
        // The method must be overridden in the derived classes.
    }
}