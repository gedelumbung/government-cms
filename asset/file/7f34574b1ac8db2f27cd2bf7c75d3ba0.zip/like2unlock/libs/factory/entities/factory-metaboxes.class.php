<?php

class PFactoryMetaBoxes 
{
    private $boxes = array();
    public $factory;
    
    public function __construct( PFactory $factory ) {
        $this->factory = $factory;
    }
    
    /**
     * Checks whether the collection is empty.
     * @return boolean
     */
    public function isEmpty() {
        return empty($this->boxes);
    }
    
    /**
     * Adds a new metabox to the collection.
     * @param PFactoryMetabox $metabox
     */
    public function add(PFactoryMetabox $metabox) {
        $metabox->factory = $this->factory;
        $this->boxes[] = $metabox;
    }
    
    /**
     * Returns all metaboxes as an array.
     * @return array
     */
    public function getAll() {
        return $this->boxes;
    }
}
