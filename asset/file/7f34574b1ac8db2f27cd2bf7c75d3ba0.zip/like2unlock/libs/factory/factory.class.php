<?php

class PFactory {
    
    /**
     * An abslute plugin's path of the current factory.
     * @var string 
     */
    public $pathRoot;
    
    /**
     * Absolute URL to plugin path.
     * @var string 
     */
    public $pluginUrl;
    
    /**
     * A loader's instance of the current factory.
     * @var PFactoryLoader 
     */
    public $loader;
    
    /**
     * Plugin name.
     * @var string.
     */
    public $pluginName;
    
    public function __construct( $pluginPath, $pluginName, $path = 'items' ) {
        
        $this->pathRoot = dirname( $pluginPath ) . '/' . $path;
        $this->pluginUrl = plugins_url( null, $pluginPath );
        $this->pluginName = $pluginName;
                
        $this->loader = new PFactoryLoader( $this );
        
        $this->setupActions();
        if ( is_admin() ) $this->setupAdminActions();
    }
    
    /**
     * Setups actions related with the factory.
     */
    private function setupActions() {
        add_action('init', array($this, 'actionInit'));
    }
    
    private function setupAdminActions() {
        add_action('admin_enqueue_scripts', array($this, 'actionAdminScripts'));
    }
    
    /**
     * WP Init action.
     * Don't excite directly.
     */
    public function actionInit() {
        $this->loader->run( is_admin() );
    }
    
    /**
     * WP admin_enqueue_scripts action.
     * Don't excite directly.
     */
    public function actionAdminScripts( $hook ) {
	global $post;

	if ( in_array( $hook, array('post.php', 'post-new.php')) && $post )
        {
            if ( !empty( $this->loader->types[$post->post_type] ) ) {
                
		wp_enqueue_style( 
                        'pfactory-bootstrap', 
                        PFACTORY_URL . '/assets/css/bootstrap.css');	
                
		wp_enqueue_script(
                        'pfactory-bootstrap', 
                        PFACTORY_URL . '/assets/js/bootstrap.js', 
                        array('jquery'));
            }
        }
    }
    
    public function clearCache() {
        $this->loader->clearCache();
    }
}