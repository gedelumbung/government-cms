<?php

class PFactoryLoader
{
    /**
     * A current factory.
     * @var PFactory
     */
    public $factory;
    
    /**
     * An absolute path for the current loading plugin.
     * @var string
     */
    public $pathRoot;
    
    /**
     * Loaded types.
     * @var array 
     */
    public $types = array();
    
    /**
     * Loader metaboxes
     * @var array 
     */
    public $metaboxes = array();
    
    /**
     * Loader view tables
     * @var array 
     */
    public $viewTables = array();  
    
    public function __construct( $factory ) {
        
        $this->factory = $factory;
        $this->pathRoot = $factory->pathRoot;
        $this->pluginName = $factory->pluginName;
    }
    
    /**
     * Starts to load plugin components.
     * @param boolean $isAdmin
     */
    public function run( $isAdmin ) {
   
        // clears the cache after reinstall
        if ( 
            get_option('factory_' . $this->pluginName. '_clear_cache') || 
            ( defined('PFACTORY_DEBUG') && PFACTORY_DEBUG ) ) {
            
            $this->clearCache();
            delete_option('factory_' . $this->pluginName. '_clear_cache');
        }
        
        $this->loadTypes( $isAdmin );
        $this->loadShortCodes( $isAdmin );

        if ( $isAdmin ) {
            $this->loadMetaboxes();
            $this->loadViewTables();
            
            // register types in admin area
            foreach ($this->types as $type) {
                $type->registerAdmin();
            } 
            
            // register metaboxes
            foreach($this->metaboxes as $metabox) {
                $metabox->register();
            }
        }
    }
    
    /**
     * Loads custom post types from the folder 'types' in the plugin's root.
     * @param bool $isAdmin
     * 
     * @todo make loading of metaboxes and tables inside only type's page.
     */
    public function loadTypes( $isAdmin )
    {
        $types = $this->loadAndRegister( 'types'  );
        
        $this->types = array();
        foreach($types as $type) {
            $this->types[$type->name] = $type;
        }
    }
    
    public function loadShortCodes( $isAdmin ) {
        
        if ( $isAdmin ) return;
        $this->loadAndRegister( 'shortcodes' );       
    }
    
    /**
     * Loads metaboxes.
     * Concats metaboxes defined in types and free metaboxes in the folder metaboxes.
     */
    public function loadMetaboxes()
    {
        $metaboxes = $this->loadAndRegister( 'metaboxes', false );
        
        foreach ($metaboxes as $metabox) {
            if ( !empty( $metabox->types ) )$this->metaboxes[] = $metabox;
        }
    }
    
    /**
     * Loads view tables.
     */
    public function loadViewTables()
    {
        $tables = $this->loadAndRegister( 'viewtables', false );
        
        foreach ($tables as $table) {
            $this->viewTables[] = $table;
        }
    }    
    
    public function loadAndRegister( $entityName, $register = true ) {
        
        $info = self::getCache( $entityName );
        if ( !$info ) {

            $info = array();
            $files = self::getFiles( $this->pathRoot . '/' . $entityName );
            
            $classes = array();            
            foreach ($files as $filepath) {
                $classes = array_merge($classes, self::getClasses($filepath));
            }
            
            $info['files'] = $files;
            $info['classes'] = $classes;
            
            self::setCache( $entityName, $info );
        }
        if (empty($info['classes'])) return false; 
        
        foreach ($info['files'] as $filepath) {
            include_once($filepath);
        }
        
        $objects = array();
        foreach ($info['classes'] as $className) {
            $obj = new $className( $this->factory );
            if ( $register ) $obj->register();
            $objects[] = $obj;
        }
                
        return $objects;
    }
    
 
    /**
     * Incldues file from a given folder using the cache.
     * @param string $folderName
     * @return array
     */
    private function includeFiles( $folderName )
    {
        $info = self::getCache( $folderName );
        if (!$info) {
            
            $info = array();
            $info['files'] = self::getFiles( $this->pathRoot . '/' . $folderName );
            
            self::setCache( $folderName, $info );
        }  
        
        if ( empty($info['files']) ) return $info['files'];
        
        foreach($info['files'] as $filename) {
            include_once($filename);
        }
        
        return $info['files'];
    }
    
    /**
     * Returns a list of files in the folder.
     * @param string $path target path
     * @return array array of files
     */
    private function getFiles( $path ) {
        if ( !is_dir($path)) return array();
        
        $entries = scandir( $path );
        if (empty($entries )) return array();

        $files = array();
        foreach($entries as $entryName) {
            $filename = $path . '/' . $entryName;
            if ( is_file($filename) ) $files[] = addslashes( $filename );
        }
        return $files;
    }
    
    /**
     * Gets php classes defined in a specified file.
     * @param type $path
     */
    private function getClasses( $path ) {
        $phpCode = file_get_contents( $path );
        
        $classes = array();
        $tokens = token_get_all($phpCode);
        $count = count($tokens);
        for ($i = 2; $i < $count; $i++) {
          if ( 
              is_array($tokens) 
              && $tokens[$i - 2][0] == T_CLASS
              && $tokens[$i - 1][0] == T_WHITESPACE
              && $tokens[$i][0] == T_STRING) {

              $class_name = $tokens[$i][1];
              $classes[] = $class_name;
          }
        }
        return $classes;   
    }
    
    private function getCache( $name ) {
        $optionName = 'factory_' . $this->pluginName . '_' . $name;
        $cache = get_option($optionName);
        if ( $cache ) return $cache;
        return false;
    }
    
    private function setCache( $name, array $values ) {
        $optionName = 'factory_' . $this->pluginName . '_' . $name;
        update_option($optionName, $values );
        return true;
    }
    
    private function clearCacheItem( $name ) {
        $optionName = 'factory_' . $this->pluginName . '_' . $name;
        delete_option($optionName);
        return true;   
    }
    
    public function clearCache() {
        $this->clearCacheItem('types');
        $this->clearCacheItem('metaboxes');
        $this->clearCacheItem('viewtables');
        $this->clearCacheItem('shortcodes');
    }
}