<?php
/**
Plugin Name: Like 2 Unlock
Plugin URI: http://codecanyon.net/item/like-2-unlock-for-wordpress/2858703?ref=onepress
Description: This is an easy-to-use Wordpress plugin that allows you to block specified content on the web page until the user clicks on the Like button. Lock the most interesting parts of your pages: images, links, text, forms, etc. It increases the number of likes and generates additional traffic from the social network. 
Author: Paul Kashtanoff (OnePress)
Version: 3.5.3
Author URI: http://codecanyon.net/user/OnePress?ref=onepress
*/

//ini_set('display_errors',1);
//error_reporting(E_ALL);

/**
 * Loads plugin's code created via Plugin Factory.
 */

// if ( !defined('define') ) define('PFACTORY_DEBUG', true);

include_once('libs/factory/start.php');
$plusOneFactory = new PFactory( __FILE__, 'like2unlock', 'items' );

/**
 * Loads non-framework plugin's code.
 */

define('LIKE_PLUGIN_ROOT', dirname(__FILE__));
define('LIKE_PLUGIN_URL', plugins_url( null, __FILE__ ));

// admin init
if ( is_admin() ) {
    include_once( LIKE_PLUGIN_ROOT . '/admin/init.php' );
    register_activation_hook( __FILE__, 'install_like_locker' );
}