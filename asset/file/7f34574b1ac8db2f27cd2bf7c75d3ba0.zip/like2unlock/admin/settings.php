<?php

function like_save_settings()
{
    ?>
    <div id="message" class="updated" style="margin: 0px; margin-top: 10px; font-weight: bold;">
        <p>Facebook Settings updated!</p></div>
    <?
	foreach($_POST as $field_name => $value)
	{
            if ( preg_match("/^like_/", $field_name)) {
                    $value = stripslashes( $value );
                    update_option( $field_name, $value );
            }
	}	
}

function like_settings() {
    if ( isset( $_POST['save-action'] ) ) like_save_settings();
?>
<link rel='stylesheet' id='thickbox-css' href='<?php echo LIKE_PLUGIN_URL . '/assets/admin/css/settings-style.css'?>' type='text/css' media='all' />

<form method="post" class="form-horizontal">

<div id="facebook" class="panel like-panel">
    <h2>Facebook Settings</h2>
    <p>Setup the App Id to use the Strict Mode or to get statistics in your app profile.</p>
    <fieldset>
    <legend></legend>
     <div class="control-group">
        <label class="control-label" for="like_facebook_appid"><?=__('Facebook App ID')?></label>
        <div class="controls">
            <input type="text" class="short"  name="like_facebook_appid" id="like_facebook_appid" placeholder="enter a facebook appid" value="<?= get_option('like_facebook_appid') ?>" />
            <span class="help-block">
                The facebook app id (to grab statistics or to use the Strict Mode).<br />
                Create an app here: <a href="https://developers.facebook.com/apps" target="_blank">https://developers.facebook.com/apps</a>.</span>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="like_facebook_lang"><?=__('Facebook Lang')?></label>
        <div class="controls">
            <input type="text" class="short"  name="like_facebook_lang" id="like_facebook_lang" placeholder="enter a facebook lang" value="<?= get_option('like_facebook_lang') ?>" />
            <span class="help-block">A language ot the facebook widgets.</span>
        </div>
    </div> 
    
    <div class="form-actions">
        <input name="save-action" class="button-primary" type="submit" value="Save changes"/>
    </div>

</fieldset>



 <div style="clear: both;"></div>
</div>
    

</form>


<?
}
