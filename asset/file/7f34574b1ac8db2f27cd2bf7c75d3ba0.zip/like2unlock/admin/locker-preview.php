<?php
    function printJsVars( $vars ) {
        
        foreach($vars as $var) {
            
            $indep = substr($var, 0, 1) == '_';
            if ($indep) {
                $var = substr($var, 1, strlen($var));
            }           
             
            $postName = str_replace('.', '_', $var);
            $value = isset( $_POST[$postName] ) ? $_POST[$postName] : null;
            
            if ( $value === '' || $value === null ) continue;

            $strValue = $value;
            if ($value === 'false') $strValue = false;
            if ($value === 'true') $strValue = true;
            if (preg_match('/^\d+$/', $value)) $strValue = intval($value);
            
            if ($indep) {
                echo 'var ' . $var . ' = ' . jsValue( $strValue ) . ';';       
            } else {
                echo 'options.' . $var . ' = ' . jsValue( $strValue ) . ';';
            }
        }
    }
    
    function jsValue( $value ) {
        
        $type = gettype($value);
        
        switch ($type) {
            case 'boolean':
                return ($value ? 'true' : 'false');
                break;
            case 'integer':
                return $value;
                break;
            default:
                return '"' . $value . '"';
                break;
        }
    }
?>
<!DOCTYPE html>
<html>
    <head>
         <meta charset="UTF-8" />
        
         <style>
             body {
                 padding: 0px;
                 margin: 0px;
                 font: normal normal 400 14px/170% Arial;
                 color: #333333;
                 text-align: justify;
                 background-color: #fff;
             }
             * {
                 padding: 0px;
                 margin: 0px;
             }
             #wrap {
                 padding: 20px;
                 overflow: hidden;
             }
             p {
                 margin: 0px;
             }
             p + p {
                 margin-top: 8px;
             }
             #wrap > .ui-locker-facebook {
                 margin: 0px !important;
             }
             #content-to-lock {
                 background-color: #fff;
                 padding: 20px;
             }
         </style>
         
         <script>
             var facebookSDK = {
                 appId: <?php echo $_POST['appid'] ?>,
                 lang: '<?php echo $_POST['lang'] ?>'
             };
         </script>
         
         <script type="text/javascript" src="./../assets/js/libs/jquery.min.js"></script>
         <script type="text/javascript" src="./../assets/js/libs/jquery-ui.min.js"></script>
         <script type="text/javascript" src="./../assets/js/jquery.op.like2unlock.min.js"></script>
         <link rel="stylesheet" type="text/css" href="./../assets/css/jquery.op.like2unlock.css">  
         
         <script>
             function alertSize() {
                 var height = $("#wrap").height();
                 height += 50;
                 if (parent && parent.updateFrameSize) parent.updateFrameSize(height);
             }
             
             var selector = null;
             var options = {};
             options.content = {};
             options.facebook = {};
             
             options.unlock = function() {
                 alertSize();
             };
             
             options.unlockByTimer = function() {
                 alertSize();
             };
                     
             options.unlockByClose = function() {
                 alertSize();
             };   
             
             options.init = function() {
                 alertSize();
             };               
             
             $(function(){
                setTimeout(function(){
                    alertSize(true);
                }, 2000);   
             })

             <?php
                printJsVars(array(
                    '_selector', 
                    'url',
                    'content.inverse',
                    'content.strict',
                    'content.text',
                    'content.button',
                    'content.similar',
                    'content.useTitle',
                    'content.useAlt',
                    'content.timer',
                    'content.close',
                    'facebook.sendButton', 
                    'facebook.layout',
                    'facebook.width',
                    'facebook.showFaces',
                    'facebook.verbToDisplay',
                    'facebook.colorScheme',
                    'facebook.font',
                    'style'
                ));
            ?>
                
            options.content.text = options.content.text 
                ? unescape(options.content.text)
                : '[Error] Plase type the locker message.';
            
            $(function(){
                selector
                    ? $("#content-to-lock").find(selector).toLike(options)
                    : $("#content-to-lock").toLike(options);            
            })
         </script>
    </head>
    <body>
        <div id="wrap">
        <div id="content-to-lock">
            <p>
                <img style='float: right; margin-left: 20px; margin-bottom: 10px;' 
                     src="../assets/admin/img/1.gif" alt="This is the alt text.">
                Aenean feugiat, urna ut facilisis molestie, sem turpis euismod nunc, suscipit 
                elementum nisl nisi vel purus. Vestibulum imperdiet lobortis diam sed feugiat. 
                Proin at cursus magna.
            </p>
            <p>
                <img style='float: left; margin-right: 20px; margin-bottom: 10px; margin-top: 10px;' 
                     src="../assets/admin/img/2.gif">
                Sed facilisis nisi eu risus sodales vulputate. Suspendisse eros dui, 
                iaculis sed consectetur pulvinar, euismod eget orci. Donec aliquet, diam quis 
                commodo blandit, nunc neque euismod nisi, quis tempor urna ligula ut metus.
            </p>
            <p>
                Mauris non leo lacus. Nullam ac urna mi. <a href="#">Fusce non metus nisi</a>. 
                In hac habitasse platea dictumst. Mauris purus purus, dignissim a iaculis vitae, 
                adipiscing semper felis.
            </p>
            <p>
                Nulla mi odio, posuere commodo elementum varius, sodales in justo. 
                Nunc convallis rhoncus odio, in cursus <a href="#">massa eleifend sit amet</a>. 
                Morbi sed erat tortor. Maecenas turpis neque, sollicitudin eget auctor in, 
                porta non justo.
            </p>
        </div>
        
        <div style="clear: both;"></div>
        </div>
    </body>
</html>