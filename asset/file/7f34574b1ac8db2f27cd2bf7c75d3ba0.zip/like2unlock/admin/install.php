<?php

function install_like_locker() {
    
    update_option('factory_like2unlock_clear_cache', true);
    
    like_default_options();
    like_create_lockers();
    flush_rewrite_rules( false ); 
}

function like_default_options()
{
	update_option('like_facebook_appid', '0');
	update_option('like_facebook_lang', 'en_US');	
}

function like_create_lockers()
{
    // [to_like]
    
    $params = array(
        'like_text'      => 'This content is locked. Please like the page to view the locked content.',
        'like_button'    => true,
        'like_theme'     => 'ui-locker-facebook-popup',
        'like_close'     => false,
        'like_similar'   => false,
        'like_timer'     => 0,
        'like_facebook_sendButton' => false,
        'like_facebook_showFaces' => false,       
        'like_useAlt'    => false,
        'like_useTitle'  => false,
        'like_selector' => '',
        'like_is_system' => true,
        'like_is_default' => 'block'
    );

    $post_id = like_create_locker('default_like2_locker', 'Default Locker', 'default_to_like2_locker_id');
    like_create_meta($post_id, $params);

    // [images_to_like]

    $params['like_text'] = 'The image is locked. Please like to unlock.';
    $params['like_similar'] = true; 
    $params['like_useAlt'] = true;   
    $params['like_useTitle'] = true;   
    $params['like_selector'] = 'img';
    $params['like_is_default'] = 'images';  
    $params['like_theme'] = 'ui-locker-default';
    $params['like_facebook_layout'] = 'button_count'; 
    	
    $post_id = like_create_locker('default_images_like2_locker', 'Default Images\' Locker', 'default_images_to_like2_locker_id');
    like_create_meta($post_id, $params);
    
    // [links_to_like] 
    
    $params['like_text'] = 'The url is locker. Please like us.';
    $params['like_similar'] = false; 
    $params['like_button'] = false;  
    $params['like_useAlt'] = false;   
    $params['like_useTitle'] = false;   
    $params['like_selector'] = 'a';
    $params['like_is_default'] = 'links'; 
    
    $post_id = like_create_locker('default_links_like2_locker', 'Default Links\' Locker', 'default_links_to_like2_locker_id');
    like_create_meta($post_id, $params);
}

function like_create_locker( $slug, $title, $option_name ) {

    global $wpdb;

	$post_id = $wpdb->get_var("SELECT ID FROM " . $wpdb->posts . " WHERE post_name = '$slug' AND post_type = 'like-locker' LIMIT 1");
	$option_value = get_option( $option_name );

    if ( !$post_id )
    {
		$create = true;
		
		if ( !empty( $option_value ) ) :
			$post_id = $wpdb->get_var( "SELECT ID FROM " . $wpdb->posts . " WHERE ID = '$option_value' AND post_type = 'like-locker' LIMIT 1" );
			if ( $post_id ) $create = false;
		endif;
		
		if ( $create ) :
			$post_data['post_title'] = $title;		
			$post_data['post_name'] = $slug;
			$post_data['post_type'] = 'like-locker';	
			$post_data['post_status'] = 'publish';
			$option_value = wp_insert_post( $post_data );
			$post_id = $option_value;
			update_option( $option_name, $option_value );
		endif;
    }
    else
    {
    	if ( empty ( $option_value ) ) :
    		update_option( $option_name, $post_id );
    	endif;
    }
	
	update_post_meta($post_id, 'fblocker_style', 'facebook-popup');
	update_post_meta($post_id, 'fblocker_effect', 'standart');	
	
	update_option( $option_name, $post_id );
	return $post_id;
}

function like_create_meta($post_id, $values) {
    
    foreach($values as $key => $value) {
        if ($value === true) $value = 'true';
        if ($value === false) $value = 'false';
        
        update_post_meta($post_id, $key, $value); 
    }
}