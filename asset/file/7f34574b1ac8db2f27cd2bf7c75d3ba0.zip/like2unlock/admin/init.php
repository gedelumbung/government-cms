<?php

include_once(LIKE_PLUGIN_ROOT . '/admin/install.php');
include_once(LIKE_PLUGIN_ROOT . '/admin/settings.php');

add_filter('mce_buttons', 'like_register_button'); 
add_filter('mce_external_plugins', 'like_add_plugin');  

function like_register_button($buttons) {  
   array_push($buttons, "tolike");
   return $buttons;  
}  

function like_add_plugin($plugin_array) {  
   $plugin_array['tolike'] = LIKE_PLUGIN_URL . '/assets/admin/js/tolike.tinymce.js';  
   return $plugin_array;  
}  

add_action('admin_menu', 'like_admin_menu');
function like_admin_menu() {
    global $menu;
    add_submenu_page( 'edit.php?post_type=like-locker', __('Facebook Settings'), __('Facebook Settings'), 'manage_options', 'like_settings', 'like_settings' );	
}

add_action('wp_ajax_get_like_lockers', 'like_get_lockers');

function like_get_lockers() {
    global $wpdb;

    $lockers = get_posts(array('post_type' => 'like-locker'));

    $result = array();
    foreach($lockers as $locker)
    {
        $result[] = array(
            'title' => empty( $locker->post_title ) ? 'No title [' . $locker->ID . ']' : $locker->post_title,
            'id' => $locker->ID,
            'defaultType' => get_post_meta( $locker->ID, 'like_is_default', true )
        );
    }

    echo json_encode($result);
    die();
}

add_action('admin_print_footer_scripts',  'like_quicktags');

function like_quicktags()
{ ?>
    <script type="text/javascript">
        (function(){
            if (!QTags) return;
            QTags.addButton( 'tolike', 'to_like', '[to_like]', '[/to_like]' );
        }());
    </script>
<?php 
}