<?php

class LikeAdvancedOptionsMetaBox extends PFactoryFormMetabox
{
    public $title = 'Advanced Options';
    public $scope = 'like';
    public $priority = 'high';
    
    public function form( PFactoryForm $form ) {
    
        $this->tabAppearance( $form );
        $this->tabGoogle( $form );  
        $this->tabEvents( $form );
    }
    
    public function beforeForm( PFactoryForm $form ) {
        ?>
        <script>
            var facebookSDKAppId = '<?php echo get_option('like_facebook_appid') ?>';
        </script>
        <?php
    }
    
    public function afterForm( PFactoryForm $form ) {
        ?>
        <div id="like_strict_hint" style="display: none;">
            The Strict Mode does not work without a Facebook App. 
            Please setup an App ID 
            on the <a href="edit.php?post_type=like-locker&page=like_settings">Settings Page</a>.</div>
        <?php
    }
    
    private function tabAppearance( PFactoryForm $form )
    {
        $form->addTab('Appearance & Behavior', 'content');
        
        $form->add(array(
     
            array(
                'type'      => 'checkbox',
                'name'      => 'inverse',
                'title'     => 'Inverse',
                'hint'      => 'Defines whether the Like Button must appears above a message of the locker.',
                'default'   => false
            ), 
            array(
                'type'      => 'checkbox',
                'name'      => 'button',
                'title'     => 'Display Like Button',
                'hint'      => 'Defines whether the Like button appears in the locker.',
                'default'   => true
            ),
            array(
                'type'      => 'checkbox',
                'name'      => 'close',
                'title'     => 'Close Button', 
                'hint'      => 'Defines whether the locker allows to unlock content
                            using the Close button placed on the top-right corner.',
                'default'   => false
            ),
            array(
                'type'   => 'integer',
                'name'   => 'timer',
                'title'  => 'Timer interval', 
                'hint'   => 'Leave the field empty to turn off the timer.',
                'size'   => 4
            ),  
            array(
                'type'  => 'checkbox',
                'name'  => 'similar',
                'title' => 'Likeness', 
                'hint'  => 'Defines whether the locker has to be similar to 
                            content that have to be locked.'
            ),
            array(
                'type'  => 'checkbox',
                'name'  => 'useTitle',
                'title' => 'Use alt', 
                'hint'  => 'Defines whether the locker has to show the
                            Title attribute of the locked content.'
            ),        
            array(
                'type'  => 'checkbox',
                'name'  => 'useAlt',
                'title' => 'Use alt', 
                'hint'  => 'Defines whether the locker has to show the
                            Alt attribute of the locked image.'
            ), 
            array(
                'type'      => 'checkbox',
                'name'      => 'strict',
                'title'     => 'Strict Mode',
                'hint'      => 'The option turns on usage of the Facebook API to check whether 
                                a user likes your URL. Please see the section "Plugin’s modes. 
                                What to choose?" in the documentation to setup it correctly.',
                'default'   => false
            ),  
            array(
                'type'  => 'textbox',
                'name'  => 'selector',
                'title' => 'Content selector',
                'hint'  => 'A selector used to select html elements for locking. 
                            The selector is added to ID of the block that have to be locked. 
                            If the field is not specified, the content is completely blocked 
                            between the opening shortcode\'s tag […] and the closing tag [/…]. 
                            For example, if you enter «img», the result selector will be 
                            «#lock-[id] img» and all images between tags will be locked.'
            ),
        ));     
    }
    
    private function tabGoogle( PFactoryForm $form ) 
    {
        $form->addTab('Facebook Like Button', 'facebook');
        
        $form->add(array(
            array(
                'type'      => 'checkbox',
                'name'      => 'facebook_sendButton',
                'title'     => 'Send Button',
                'hint'      => 'Include a Send button.',
                'default'   => false
            ),
            array(
                'type'  => 'list',
                'name'  => 'facebook_layout',
                'title' => 'Layout',
                'data'  => array(
                    array('standart', 'standart'),
                    array('button_count', 'Button Count'),
                    array('box_count', 'Box Count')
                ),
                'hint'  => 'Layout Style. Determines the size and amount of social context next to the button.'
            ),
            array(
                'type'    => 'integer',
                'name'    => 'facebook_width',
                'title'   => 'Width',
                'hint'    => 'The width of the Facebook Like Button frame, in pixels.',
                'size'    => 5,
                'append'  => 'px'
            ),
            array(
                'type'  => 'checkbox',
                'name'  => 'facebook_showFaces',
                'title' => 'Show Faces',
                'hint'  => 'Show profile pictures below the button.'
            ),      
            array(
                'type'  => 'list',
                'name'  => 'facebook_verbToDisplay',
                'title' => 'Verb to display',
                'data'  => array(
                    array('like', 'Like'),
                    array('recommend', 'Recommend')
                ),
                'hint'  => 'Only values "like" and \'recommend\' are allowed.'
            ),  
            array(
                'type'      => 'list',
                'name'      => 'facebook_colorScheme',
                'title'     => 'Color scheme',
                'data'  => array(
                    array('light', 'Light'),
                    array('dark', 'Dark')
                ),
                'hint'      => 'Only values \'light\' and \'dark\' are allowed.',
            ),    
            array(
                'type'      => 'textbox',
                'name'      => 'facebook_font',
                'title'     => 'Font',
                'hint'      => 'The font of labels.',
            ),       
        ));
    }
    
    private function tabEvents( $form )
    {
        $form->addTab('Events');
        
        $form->add(array(
            array(
                'type'  => 'textarea',
                'name'  => 'likeEvent',
                'title' => 'Unlock Event',
                'hint'  => 'Add javascript code you want to execute when 
                            a user "likes" your URL (content is unlocked).'
            ),
            array(
                'type'  => 'textarea',
                'name'  => 'unlikeEvent',
                'title' => 'Lock Event',
                'hint'  => 'Add javascript code you want to execute when 
                            a user "unlike" your URL (content is locked).'
            ),        
        ));
    }
}