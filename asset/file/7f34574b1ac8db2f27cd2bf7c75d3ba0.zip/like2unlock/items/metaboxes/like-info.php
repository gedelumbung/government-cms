<?php

class LikeInfoMetaBox extends PFactoryMetabox
{
    public $title = 'Support';
    public $priority = 'core';
    public $context = 'side';
    
    public function render()
    {
        ?>
        <div class="panel">
            <p>If you have any questions or need help please feel free to contact us via:</p>
            <ul>
                <li>CodeCanyon <a href="http://codecanyon.net/user/OnePress?ref=onepress">contact form</a></li>
                <li>Email: <a href="mailto: pavelkashtanoff@gmail.com">pavelkashtanoff@gmail.com</a></li>
            </ul>
            <p>We guarantee to respond to every inquiry within <strong>1 business day</strong> (typical response time is 3 hours).</p>
            <p class="pi-highlight"><a href="http://codecanyon.net/user/OnePress/portfolio?ref=onepress" target="_blank">View recent OnePress items</a></p>
        </div>
        <?php
    }
}