<?php

class LikePreviewMetaBox extends PFactoryMetabox
{
    public $title = 'Preview';
    public $priority = 'high';
    
    public function render()
    {
        ?>
        <script>
            function updateFrameSize(height) {
                jQuery("#lock-preview-wrap iframe").height(height);
            }
        </script>
        <p>Note: the Like Button doesn't work correctly in the admin area. It's just a preview.</p>
        <div id="lock-preview-wrap" 
             data-sdk-lang="<?php echo get_option('like_facebook_lang') ?>" 
             data-sdk-appid="<?php echo get_option('like_facebook_appid') ?>" 
             data-url="<?php echo $this->factory->pluginUrl ?>/admin/locker-preview.php">
            <iframe 
                allowtransparency="1" 
                frameborder="0" 
                hspace="0" 
                marginheight="0"
                marginwidth="0"
                name="preview"
                vspace="0"
                width="100%">
                Your browser doen't support the iframe tag.
            </iframe>
        </div>
        <?php
    }
}