<?php

class LikeBasicOptionsMetaBox extends PFactoryFormMetabox
{
    public $title = 'Basic Options';
    public $scope = 'like';
    public $priority = 'high';
    
    public function form( PFactoryForm $form ) {

        $form->add(array(
            array(
                'type'  => 'url',
                'name'  => 'url',
                'title' => 'URL to like',
                'hint'  => 'Leave this field empty to use an URL of the page 
                            where the locker will appear.',
            ),
            array(
                'type'      => 'editor',
                'name'      => 'text',
                'title'     => 'Locker message',
                'hint'      => 'Any HTML tags are allowed.',
                'default'   => 'The content is locked. Please like us to view the hidden content.',
                'eventCallback' => 'like_editor_callback'
            ),
            array(
                'type'      => 'list',
                'name'      => 'theme',
                'data'      => array(
                    array('ui-locker-default', 'Pure'),
                    array('ui-locker-standart', 'Standart'),
                    array('ui-locker-facebook-popup', 'Facebook Popup'),
                    array('ui-locker-facebook-message', 'Facebook Message'),
                    array('ui-locker-facebook-request', 'Facebook Request'),
                    array('ui-locker-facebook-request-n2', 'Facebook Request N2')                
                ), 
                'title'     => 'Theme',
                'hint'      => 'Select one of the preset themes. See the documentation to learn how to customize the theme.',
                'default'   => 'ui-locker-facebook-popup'
            )
        ));   
    }
    
    public function beforeForm( PFactoryForm $form ) {
        global $post;
        
        $urlError = get_post_meta($post->ID, 'like_page_error', true);
        if (!empty($urlError)) {
            ?>

            <div id="url-error" style="display: none;">
                <?php echo $urlError ?>
            </div>

            <?php
        }
    } 
    
    /**
     * Gets page id on save.
     */
    public function saveForm( $post_id ) {
        
        // Checks whether we are allowed to get content of a remove URL
        $allowToOpenUrl = ini_get('allow_url_fopen');
        if ( !$allowToOpenUrl || $allowToOpenUrl == '0' ) {
            ?>
                <div style="margin: 20px auto; width: 600px; padding: 20px 40px; background-color: #f9f9f9;">
                <p>Your PHP settings disallow to get content of a remote URL. 
                The plugin requires to call Facebook Graph for getting Page Id of a specified URL.</p> 
                <p>Please set the PHP setting <strong>allow_url_fopen</strong> 
                    to value <strong>1</strong> in your configuration file php.ini.</p>
                </div>
            <?php
        }
        
        // Clears error state
        update_post_meta($post_id, 'like_page_error', null);
        
        // Check if all required datum are set
        $url = isset( $_POST['like_url'] ) ? $_POST['like_url'] : null;
        if ( empty($url) ) {
            update_post_meta($post_id, 'like_page_id', null);
            return;
        }
        
        $strictMode = isset( $_POST['like_strict'] );
        if ( !$strictMode ) {
            update_post_meta($post_id, 'like_page_id', null);
            return;
        }

        $appId = get_option('like_facebook_appid');
        if (empty($appId)) {
            update_post_meta($post_id, 'like_page_id', null);
            return;
        }
        
        // Info about last check attempt
        $lastCheckUrl = get_post_meta($post_id, 'like_last_check_url', true);
        $pageId = get_post_meta($post_id, 'like_page_id', true);
        
        // If info are the same, exit.
        if (!empty($pageId) && $url == $lastCheckUrl) return;
        update_post_meta($post_id, 'like_page_id', null);
        
        // Request to Facebook Graph
        $requestId = urlencode( $url );
        
        if (preg_match('/https?\:\/\/(www.?)?facebook.com\/([a-z0-9\_\-]+)/i', $url, $matches)) {
            $requestId = $matches[2];
        }
        
        $requestUrl = 'http://graph.facebook.com?id=' . $requestId;
        
        $headers = get_headers($requestUrl);
        $code = substr($headers[0], 9, 3);
        
        if ( $code == '404' || $code == '400') {
            update_post_meta($post_id, 'like_page_error', 
                    'The specified fan page or website URL is not registered in Facebook. 
                     Please check URL correctness or <a href="' . $requestUrl . '" target="_blank">view it</a>.'); 
            return;
        }
        
        $response = file_get_contents($requestUrl);
        $response = json_decode($response);

        if ( !empty($response->id) && intval($response->id) > 0 ) {
            
            update_post_meta($post_id, 'like_page_id', $response->id);
            update_post_meta($post_id, 'like_last_check_url', url);
            
        } else {
            
            update_post_meta($post_id, 'like_page_error', 
                    'The page does not have ID in Facebook Graph. 
                    Maybe the page does not have any Likes or the Like Button 
                    is not installed on the page. The locker will not work correctly using the Strict Mode 
                    for the specified URL.');  
        }
    }
}