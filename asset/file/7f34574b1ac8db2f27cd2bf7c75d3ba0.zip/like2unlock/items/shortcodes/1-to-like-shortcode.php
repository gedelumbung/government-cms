<?php

class LikeToLikeShortcode extends PFactoryShortcode {
    
    /**
     * Shortcode name
     * @var string
     */
    public $shortcode = 'to_like';
    
    /**
     * Array used to store js params to call the jquery plugin.
     * @var type
     */
    public $jsCalls = array();
            
    public function configure(PFactoryScriptList $scripts, PFactoryStyleList $styles) {
        
        $scripts->requireItem('jquery', 'jquery-ui-core', 'jquery-ui-widget');    
        
        $scripts->addItem('~/js/jquery-ui-effects.min.js');
        $scripts->addItem('~/js/jquery.op.like2unlock.min.js');
        
        $styles->addItem('~/css/jquery.op.like2unlock.css');
                
	$facebookSDK = array( 
		'appId' => get_option('like_facebook_appid', 0 ),
		'lang' => get_option('like_facebook_lang', 'en_US' ) 
	);   
        $scripts->localize('~/js/jquery.op.like2unlock.min.js', 'facebookSDK', $facebookSDK);
    }
    
    public function render($attr, $content) { 
        
        // - 1. Options loading 

        // locker id
        $id = isset( $attr['id'] ) ? (int)$attr['id'] : get_option('default_' . $this->shortcode . '2_locker_id');

        if ( empty($id) ) {
            echo '<div><strong>[Like 2 Unlock] The locked doesn\'t exist or the default lockers was deleted.</strong></div>'; 
            return;
        }

        // - 2. Build options' array

        if (!function_exists('like_get_meta')) {
            function like_get_meta($id, $name) {
                return get_post_meta($id, 'like_' . $name, true);
            }
        }
 
        $params = array(
            
            'url' => like_get_meta($id, 'url'),
            'style' => like_get_meta($id, 'theme'),
            'pageId' => like_get_meta($id, 'page_id'),
            
            'content' => array(
                'inverse'   => like_get_meta($id, 'inverse'),
                'text'      => like_get_meta($id, 'text'),
                'close'     => like_get_meta($id, 'close'),
                'button'    => like_get_meta($id, 'button'),
                'useAlt'    => like_get_meta($id, 'useAlt'),  
                'useTitle'  => like_get_meta($id, 'useTitle'), 
                'similar'   => like_get_meta($id, 'similar'),
                'timer'     => like_get_meta($id, 'timer'),
                'strict'    => like_get_meta($id, 'strict')
            ),
            'facebook' => array(
                'sendButton'            => like_get_meta($id, 'facebook_sendButton'),
                'layout'      => like_get_meta($id, 'facebook_layout'),
                'width'           => like_get_meta($id, 'facebook_width'),
                'showFaces'           => like_get_meta($id, 'facebook_showFaces'),
                'verbToDisplay'        => like_get_meta($id, 'facebook_verbToDisplay'),
                'colorScheme' => like_get_meta($id, 'facebook_colorScheme'),
                'font' => like_get_meta($id, 'facebook_font'),
            ),
            'lock' => 'function(){' . like_get_meta($id, 'unlikeEvent') . '}',
            'unlock' => 'function(){' . like_get_meta($id, 'likeEvent') . '}',      
        );

        $selector = like_get_meta($id, 'selector');

        if ( isset( $attr['url'] ) ) $params['url'] = $attr['url'];	
        if ( isset( $attr['text'] ) ) $params['content']['text'] = $attr['text'];
        if ( isset( $attr['class'] ) ) $params['theme'] = empty( $params['theme'] ) 
            ? $attr['class'] : $params['theme'] . ' ' . $attr['class'];
     
        $this->clearParams( $params );
        
        // - 3. Markup and script generation 

        $rand = rand(100000, 999999);
        $blockId = "lock-" . $rand;
        $resultSelector = '#' . $blockId . ' ' . $selector;

        $content = preg_replace( '/^<br \/>/', '', $content );
        $content = preg_replace( '/<br \/>$/', '', $content );
        $content = do_shortcode( $content );
        
        ?>
            <?php if (empty( $selector ) ) { ?>
                <div id='<? echo $blockId ?>' style="display: none;">
                <p><?php echo  $content ?></p>
                </div>
            <?php } else { ?>
                <div id='<?php echo $blockId ?>'>
                <p><?php echo $content ?></p>
                </div>   
            <?php } ?>
        <?php
        
        $this->jsCalls[] = array(
            'selector'  => $resultSelector,
            'params'    => $params
        );
        
        add_action('wp_footer', array(&$this, 'callLocker'), 1000);
    }

    public function callLocker() {
        
        foreach($this->jsCalls as $call) {
            
            $lockEvent = $call['params']['lock'];
            $unlockEvent = $call['params']['unlock'];
            
            unset($call['params']['lock']);
            unset($call['params']['unlock']);
            ?>
            <script>
                (function($){
                    $(function(){
                        var toLikeOptions = <?= json_encode($call['params']) ?>;
                        <?php if (!empty($call['params']['url'])) { ?>
                            toLikeOptions['url'] = "<?php echo $call['params']['url'] ?>";
                        <?php } ?>
                        toLikeOptions['lock'] = <?php echo $lockEvent ?>;
                        toLikeOptions['unlock'] = <?php echo $unlockEvent ?>;
                        $("<?=$call['selector']?>").toLike( toLikeOptions );			
                    })
                })(jQuery);
            </script>
            <?
        } 
    }
    
    public function clearParams( &$params ) {
        
        foreach( $params as $key => &$item ) {
            
            if ( $item === '' || $item === null || $item === 0 ) {
                unset( $params[$key] );
                continue;
            }
            
            if ( $item === 'true' ) {
                $params[$key] = true;
                continue;
            }            
            
            if ( $item === 'false' ) {
                $params[$key] = false;
                continue;
            }               
            
            if ( gettype($item) == 'array' ) {
                $this->clearParams( $params[$key] );
            }
        }
    }
}