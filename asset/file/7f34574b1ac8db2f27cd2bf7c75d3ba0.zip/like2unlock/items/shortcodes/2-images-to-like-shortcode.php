<?php

class LikeImagesToLikeShortcode extends LikeToLikeShortcode {
    
    /**
     * Shortcode name
     * @var string
     */
    public $shortcode = 'images_to_plus';
}