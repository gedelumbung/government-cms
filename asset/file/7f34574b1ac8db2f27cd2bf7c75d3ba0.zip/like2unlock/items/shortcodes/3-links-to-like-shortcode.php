<?php

class LikeLinksToLikeShortcode extends LikeToLikeShortcode {
    
    /**
     * Shortcode name
     * @var string
     */
    public $shortcode = 'links_to_plus';
}