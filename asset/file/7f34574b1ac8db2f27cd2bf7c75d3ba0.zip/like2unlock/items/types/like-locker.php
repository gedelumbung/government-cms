<?php

class LikeLockerType extends PFactoryType {
    
    public $name = 'like-locker';
    
    public $singularTitle = 'Locker';
    public $pluralTitle = 'Lockers';
    public $description = 'Like Button lockers.';
    public $template = 'private';

    public function configure( 
            PFactoryType $type, PFactoryTypeMenu $menu, PFactoryMetaBoxes $metaboxes ) {
        
        /**
         * Menu
         */
        
        $menu->title = 'Like Lockers';
        $menu->icon = '~/assets/admin/img/menu-icon.png';
        
        /**
         * Metaboxes
         */
        
        $metaboxes->add( new LikeBasicOptionsMetaBox() );
        $metaboxes->add( new LikePreviewMetaBox() );
        $metaboxes->add( new LikeAdvancedOptionsMetaBox() ); 
        $metaboxes->add( new LikeInfoMetaBox() );
        
        /**
         * View table
         */
        
        $type->viewTable = new LikeLockerViewTable();
        
        /**
         * Scripts & styles
         */
                
        $type->adminScripts->addItem('~/admin/js/locker-edit.js');       
        $type->adminStyles->addItem('~/admin/css/locker-edit.css');
    }
}