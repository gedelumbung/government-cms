<?php

class LikeLockerViewTable extends PFactoryViewTable
{
    public function configure( PFactoryViewTable $table )
    {
        /**
         * Columns
         */
        
        $columns = $table->columns;
        
        $columns->clear();
        $columns->add('title', 'Title');
        $columns->add('shortcode', 'Shortcode'); 
        $columns->add('theme', 'Theme');
        $columns->add('created', 'Created');
        
        /**
         * Scripts & styles
         */
                
        $table->adminScripts->addItem('~/admin/js/locker-table.js');       
        $table->adminStyles->addItem('~/admin/css/locker-table.css');
    }
    
    /**
     * Column 'Title'
     */
    public function columnTitle( $post, $isFullMode ) {
        if ($isFullMode ) {
            
           $url = get_post_meta($post->ID, 'like_theme', true);
           if ( empty($url) ) $url = '<i>[current page]</i>';
           
           echo '<p>' . $post->post_title . '</p>';
           echo '<p>' . $url . '</p>';
        } else {
            echo $post->post_title;
        }
    }
    
    /**
     * Column 'Shortcode'
     */ 
    public function columnShortcode( $post, $isFullMode ) {
        
        $defaultType = get_post_meta( $post->ID, 'like_is_default', true);
        
        switch ($defaultType) {
            
            case 'block':
                ?>
                <input class="shortcode" type="text" value='[to_like] [/to_like]' />
                <?php 
                break;
            
            case 'images':
                ?>
                <input class="shortcode" type="text" value='[images_to_like] [/images_to_like]' />
                <?php 
                break;
            
            case 'links':
                ?>
                <input class="shortcode" type="text" value='[links_to_like] [/links_to_like]' />
                <?php 
                break;           
            
            default:
                ?>
                <input class="shortcode" type="text" value='[to_like id="<?php echo $post->ID ?>"] [/to_like]' />
                <?php  
                break;
        }
    }
    
    /**
     * Column 'Theme'
     */
    public function columnTheme( $post, $isFullMode ) {
        
        $theme = get_post_meta($post->ID, 'like_theme', true);
        
        switch($theme) {
            case 'ui-locker-default':
                echo 'Pure';
                break;
            case 'ui-locker-standart':
                echo 'Standart';
                break;            
            case 'ui-locker-facebook-popup':
                echo 'Facebook Popup';
                break;
            case 'ui-locker-facebook-message':
                echo 'Facebook Message';
                break;
           case 'ui-locker-facebook-request':
                echo 'Facebook Request';
                break;        
           case 'ui-locker-facebook-request-n2':
                echo 'Facebook Request N2';
                break;     
            default:
                echo $theme;
                break;
        }
    }
    
     /**
     * Column 'Created'
     */
    public function columnCreated( $post, $isFullMode ) {
        
        $t_time = get_the_time( 'Y/m/d g:i:s A' );
        $m_time = $post->post_date;
        $time = get_post_time( 'G', true, $post );

        $time_diff = time() - $time;

        if ( $time_diff > 0 && $time_diff < 24*60*60 )
            $h_time = sprintf( __( '%s ago', 'jigoshop' ), human_time_diff( $time ) );
        else
            $h_time = mysql2date( __( 'Y/m/d', 'jigoshop' ), $m_time );
        
        echo '<abbr title="' . esc_attr( $t_time ) . '">' . $h_time . '</abbr><br />';
    }
}