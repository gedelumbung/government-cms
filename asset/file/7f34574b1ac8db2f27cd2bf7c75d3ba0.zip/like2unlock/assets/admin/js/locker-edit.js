(function($){
    $(function(){

        $("#LikeBasicOptionsMetaBox input")
            .add("#LikeBasicOptionsMetaBox select")
            .add("#LikeBasicOptionsMetaBox textarea")
            .add("#LikeAdvancedOptionsMetaBox input")
            .add("#LikeAdvancedOptionsMetaBox select")
            .add("#LikeAdvancedOptionsMetaBox textarea")            
            .change(function(){
               postpone_preview();
            })
            .keyup(function(){
               postpone_preview();
            });
       
       var $urlError = $("#url-error");
       if ( $urlError.length > 0 ) {
           
            $urlError.insertAfter( 
                $("#like_url").parents(".control-group").find('.help-block') 
            ).show();
       }
       
       var $strictCheckbox = $("#like_strict"),
           $strictBlock = $strictCheckbox.parents(".control-group"),
           $strictHint = $("#like_strict_hint").insertAfter( $strictBlock.find('.help-block') );

        if ( $strictCheckbox.is(':checked') ) {
            if ( parseInt(facebookSDKAppId) == 0 ) { 
                $strictHint.show();
            }
        }
        
       $strictCheckbox.change(function(){

           if ( $strictCheckbox.is(':checked') ) {
               if ( parseInt(facebookSDKAppId) == 0 ) {
                   $strictHint.fadeIn(500);
               }
           } else {
               if ( parseInt(facebookSDKAppId) == 0 ) {
                $strictHint.fadeOut(500);
               }
           }
       });
    
        recreate_preview();
    });
    
})(jQuery)

function like_editor_callback(e) {
    if ( e.type == 'keyup') {
        tinyMCE.activeEditor.save();
        postpone_preview();
    }
    return true;
}

var $form = null;
var timerOn = false;
var timerAgain = false;

function postpone_preview( force ) {

    if ( timerOn && !force ) {
        timerAgain = true;
        return;
    }

    timerOn = true;
    setTimeout(function(){

        if (timerAgain) {
            timerAgain = false;
            postpone_preview( true );
        } else {
            timerAgain = false;
            timerOn = false;
            recreate_preview();
        }

    }, 500);
}

function recreate_preview() {

    var $preview = jQuery("#lock-preview-wrap");
    var $iframe = $preview.find('iframe');

    var preview_options = collect_preview_options();
    preview_options.selector = jQuery("#like_selector").val();
    
    preview_options.lang = $preview.data('sdk-lang'); 
    preview_options.appid = $preview.data('sdk-appid');

    if ( $form ) {
        $form.remove();
        $form = null;
    }

    $form = jQuery("<form method='post' target='preview'></form>");
    $form.attr('action', $preview.data('url'));
    createFields(null, $form, preview_options);
    $form.appendTo(jQuery("body"));
    $form.submit();
   // alert($form.parent().html());
}

function createFields(base, $form, values) {

    for( propName in values ) {

        if (typeof(values[propName]) === 'object') {
            createFields(propName, $form, values[propName]);
        } else { 
            if (values[propName] == null) continue;
            $form.append(
                jQuery("<input type='hidden' name='" + 
                    (base ? (base + "_" + propName) : propName)  + "' value='" + 
                    values[propName] + "' />")
            );
        } 
    }
}

function collect_preview_options() {

    var timer = parseInt( jQuery("#like_timer").val() );
    var googleWidth = jQuery("#like_facebook_width").val();
    facebookWidth = googleWidth ? parseInt(googleWidth) : googleWidth;
    
    var preview_options = {
        url: 'http://www.codecanyon.com?' + Math.random(),
        content: {
                inverse: jQuery("#like_inverse").is(':checked'),
                text: escape( jQuery("#like_text").val() ),
                strict: jQuery("#like_strict").is(':checked'),
                button: jQuery("#like_button").is(':checked'),
                similar: jQuery("#like_similar").is(':checked'),
                useTitle: jQuery("#like_useTitle").is(':checked'),
                useAlt: jQuery("#like_useAlt").is(':checked'),
                timer: timer == 0 ? null : timer,		
                close: jQuery("#like_close").is(':checked')					
        },
        facebook: {
                sendButton: jQuery("#like_facebook_sendButton").is(':checked'),
                layout: jQuery("#like_facebook_layout").val(),
                width: googleWidth == 0 ? null : facebookWidth,
                showFaces: jQuery("#like_facebook_showFaces").is(':checked'),
                verbToDisplay: jQuery("#like_facebook_verbToDisplay").val(),
                colorScheme: jQuery("#like_facebook_colorScheme").val(),
                font: jQuery("#like_facebook_font").val()
        },
        style: jQuery("#like_theme").val()
    };

    return preview_options;     
}