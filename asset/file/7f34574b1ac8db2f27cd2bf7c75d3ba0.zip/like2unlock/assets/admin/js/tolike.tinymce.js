(function() {  
    tinymce.create('tinymce.plugins.tolike', {  
            plugin_url: null,
            editor: null,
		
        init : function(ed, url) {  

			this.plugin_url = url;
			this.editor = ed;
        },
        createControl : function(n, cm) {  
			var self = this;
			
			if ( n == 'tolike' )
			{
				var selectedValue = null;
				var selectedDefaultType = 'block';
				
                var c = cm.createSplitButton('tolike', {
                    title : 'Split button',
                    image : self.plugin_url + '/../img/tolike.png',
                    onclick : function() {
                        self.insertShortCode(selectedValue, selectedDefaultType);
                    }
                });
				
                jQuery(document).ready(function($) {

                        $.ajax(ajaxurl, {
                                type: 'post',
                                dataType: 'json',
                                data: {
                                        action: 'get_like_lockers'
                                },
                                success: function(data, textStatus, jqXHR) {

                                        c.onRenderMenu.add(function(c, m) {

                                                m.add({title : 'Lockers', 'class' : 'mceMenuItemTitle'}).setDisabled(1);

                                                var menuItems = [];

                                                $.each(data, function(index, item){

                                                        var mItem = m.add({title : item.title, onclick : function(e, a) {

                                                                for(index in menuItems) {
                                                                        menuItems[index].setSelected(false);
                                                                }

                                                                mItem.setSelected(true);

                                                                selectedValue = item.id;
                                                                selectedDefaultType = item.defaultType;

                                                                self.insertShortCode(selectedValue, selectedDefaultType);
                                                        }});
                                                        menuItems.push(mItem);
                                                });
                                        });
                                }
                        });
                });

                // Return the new splitbutton instance
                return c;
			}
			
			return null;
        },  
		
		insertShortCode: function(value, defaultType) {
			var self = this;
			
			if ( !value ) {
				self.editor.selection.setContent('[to_like]' + self.editor.selection.getContent() + '[/to_like]');  
			} else {
				
				switch(defaultType)
				{
					case "block":
						self.editor.selection.setContent('[to_like]' + self.editor.selection.getContent() + '[/to_like]');
						break;
						
					case "images":
						self.editor.selection.setContent('[images_to_like]' +  self.editor.selection.getContent() + '[/images_to_like]');
						break;
                                                
					case "links":
						self.editor.selection.setContent('[links_to_like]' +  self.editor.selection.getContent() + '[/links_to_like]');
						break;                                           
					
					default:
						self.editor.selection.setContent('[to_like id="' + value + '"]' +  self.editor.selection.getContent() + '[/to_like]');
						break;
				}			
			}
		}
    });  
    tinymce.PluginManager.add('tolike', tinymce.plugins.tolike);  
})();  